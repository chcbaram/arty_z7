/*
 *  bsp.h
 *
 *  boart support package
 *
 *  Created on: 2017. 3. 16.
 *      Author: Baram
 */

#ifndef BSP_H
#define BSP_H


#ifdef __cplusplus
 extern "C" {
#endif


#include <stdint.h>

#include "def.h"
#include "xil_printf.h"



#define STDOUT_IS_PS7_UART





void bspInit();
void bspDeinit();



#ifdef __cplusplus
}
#endif
#endif
