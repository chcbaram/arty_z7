/*
 *  led.c
 *
 *  Created on: 2016. 7. 13.
 *      Author: Baram
 */
#include "hw.h"
#include "led.h"
#include "xgpio.h"




XGpio led_gpio;



typedef struct
{
  uint16_t      pin_number;
} led_port_t;



int ledCmdif(int argc, char **argv);




void ledInit(void)
{
  uint32_t i;
  int ret;



  ret = XGpio_Initialize(&led_gpio, XPAR_GPIO_0_DEVICE_ID);
  if (ret != XST_SUCCESS)
  {
    return;
  }

  XGpio_SetDataDirection(&led_gpio, 1, 0x00);


  for (i=0; i<LED_CH_MAX; i++)
  {
    ledOff(i);
  }


  cmdifAdd("led", ledCmdif);
}

void ledOn(uint8_t ch)
{
  if (ch >= LED_CH_MAX) return;


  XGpio_DiscreteSet(&led_gpio, 1, (1<<ch));
}

void ledOff(uint8_t ch)
{
  if (ch >= LED_CH_MAX) return;


  XGpio_DiscreteClear(&led_gpio, 1, (1<<ch));
}

void ledToggle(uint8_t ch)
{
  uint32_t ret;


  if (ch >= LED_CH_MAX) return;


  ret  = XGpio_DiscreteRead(&led_gpio, 1);
  ret ^= (1<<ch);

  XGpio_DiscreteWrite(&led_gpio, 1, ret);
}



//-- ledCmdif
//
int ledCmdif(int argc, char **argv)
{
  bool ret = true;
  uint8_t number;


  if (argc == 3)
  {
    number = (uint8_t) strtoul((const char * ) argv[2], (char **)NULL, (int) 0);

    if(strcmp("on", argv[1]) == 0)
    {
      ledOn(number);
    }
    else if(strcmp("off", argv[1])==0)
    {
      ledOff(number);
    }
    else if(strcmp("toggle", argv[1])==0)
    {
      ledToggle(number);
    }
    else if(strcmp("demo", argv[1])==0)
    {
      while(cmdifRxAvailable() == 0)
      {
        ledToggle(number);
        delay(200);
        cmdifPrintf("led toggle %d\n", number);
      }
    }
    else
    {
      ret = false;
    }
  }
  else
  {
    ret = false;
  }

  if (ret == false)
  {
    cmdifPrintf( "led on/off/toggle/demo number ...\n");
  }

  return 0;
}
