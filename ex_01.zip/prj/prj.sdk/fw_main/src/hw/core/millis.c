/*
 *  millis.c
 *
 *  Created on: 2016. 7. 13.
 *      Author: Baram
 */

#include "millis.h"
#include "xtime_l.h"










void millisInit()
{
}

uint32_t millis()
{
  XTime tCur;
  XTime tMillis;

  XTime_GetTime(&tCur);



  tMillis  = tCur / (COUNTS_PER_SECOND/1000);

  return (uint32_t)tMillis;
}
