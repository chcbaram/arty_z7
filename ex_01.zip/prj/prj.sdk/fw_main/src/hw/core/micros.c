/*
 *  micros.c
 *
 *  Created on: 2016. 7. 13.
 *      Author: Baram
 */

#include "micros.h"
#include "xtime_l.h"








void microsInit()
{

}


uint32_t micros()
{
  XTime tCur;
  XTime tMicros;

  XTime_GetTime(&tCur);



  tMicros  = tCur / (COUNTS_PER_SECOND/1000000);

  return (uint32_t)tMicros;
}
