/*
 * uart.c
 *
 *  Created on: 2017. 2. 13.
 *      Author: baram
 */
/*
  _HW_DEF_UART_CH_MAX : 2
*/


#include <stdio.h>
#include <stdarg.h>
#include <stdbool.h>
#include "hw.h"
#include "xuartps.h"
#include "xil_exception.h"
#include "xil_printf.h"

#ifdef XPAR_INTC_0_DEVICE_ID
#include "xintc.h"
#else
#include "xscugic.h"
#endif



#include "uart.h"



#define UART_RX_BUF_LENGTH    64



#ifdef XPAR_INTC_0_DEVICE_ID
#define INTC    XIntc
#define UART_DEVICE_ID    XPAR_XUARTPS_0_DEVICE_ID
#define INTC_DEVICE_ID    XPAR_INTC_0_DEVICE_ID
#define UART_INT_IRQ_ID   XPAR_INTC_0_UARTPS_0_VEC_ID
#else
#define INTC    XScuGic
#define UART_DEVICE_ID    XPAR_XUARTPS_0_DEVICE_ID
#define INTC_DEVICE_ID    XPAR_SCUGIC_SINGLE_DEVICE_ID
#define UART_INT_IRQ_ID   XPAR_XUARTPS_1_INTR
#endif




//-- Internal Variables
//
uart_t  uart_tbl[_HW_DEF_UART_CH_MAX];
uint8_t uart_buffer[2][UART_RX_BUF_LENGTH];


XUartPs UartPs;
INTC    InterruptController;


//-- External Variables
//


//-- Internal Functions
//
static bool uartIsEnable(uint8_t channel);



//-- External Functions
//


//-- Driver Functions
//




bool uartInit(void)
{
  uint32_t i;
  int Status;
  XUartPs_Config *Config;


  for(i=0; i<_HW_DEF_UART_CH_MAX; i++)
  {
    uart_tbl[i].is_open           = false;
    uart_tbl[i].hw.rx_buf.ptr_in  = 0;
    uart_tbl[i].hw.rx_buf.ptr_out = 0;
    uart_tbl[i].hw.rx_buf.p_buf   = NULL;
    uart_tbl[i].hw.vcp_enable     = false;
    uart_tbl[i].hw.dma_enable     = false;
  }


  Config = XUartPs_LookupConfig(UART_DEVICE_ID);
  if (NULL == Config)
  {
    return false;
  }

  Status = XUartPs_CfgInitialize(&UartPs, Config, Config->BaseAddress);
  if (Status != XST_SUCCESS)
  {
    return false;
  }

  return true;
}

uint32_t uartOpen(uint8_t channel, uint32_t baud)
{
	uint32_t err_code  = OK;
	uart_t *p_drv_uart = &uart_tbl[channel];


  if (channel >= _HW_DEF_UART_CH_MAX)
  {
    return 1;
  }



  switch(channel)
  {
    case _DEF_UART1:
      p_drv_uart->baud           = baud;
      p_drv_uart->hw.rx_buf.ptr_in  = 0;
      p_drv_uart->hw.rx_buf.ptr_out = 0;
      p_drv_uart->hw.rx_buf.p_buf   = (uint8_t *)uart_buffer[0];
      p_drv_uart->hw.rx_buf.length  = UART_RX_BUF_LENGTH;
      p_drv_uart->is_open = true;


      XUartPs_SetOperMode(&UartPs, XUARTPS_OPER_MODE_NORMAL);
      XUartPs_SetBaudRate(&UartPs, baud);
      break;
  }





  return err_code;
}

bool uartIsEnable(uint8_t channel)
{
  if (channel >= _HW_DEF_UART_CH_MAX)
  {
    return false;
  }


  return uart_tbl[channel].is_open;
}

uint32_t uartAvailable(uint8_t channel)
{
  uint32_t length = 0;
  uart_t *p_drv_uart = &uart_tbl[channel];


  length = (   p_drv_uart->hw.rx_buf.length
             + p_drv_uart->hw.rx_buf.ptr_in
             - p_drv_uart->hw.rx_buf.ptr_out ) % p_drv_uart->hw.rx_buf.length;



  if ((XUartPs_ReadReg(UartPs.Config.BaseAddress, XUARTPS_SR_OFFSET) & (1<<1)) == 0)
  {
    length = 1;
  }
  else
  {
    length = 0;
  }

  return length;
}

void uartPutch(uint8_t channel, uint8_t ch)
{
  uartWrite(channel, &ch, 1 );
}

uint8_t uartGetch(uint8_t channel)
{
  if (uartIsEnable(channel) == false ) return 0;


  while(1)
  {
    if( uartAvailable(channel) ) break;
  }


  return uartRead(channel);
}

int32_t uartWrite(uint8_t channel, uint8_t *p_data, uint32_t length)
{
  int32_t  ret = 0;


  if (uartIsEnable(channel) == false ) return 0;


  ret = XUartPs_Send(&UartPs, p_data, length);


  while (XUartPs_IsSending(&UartPs)) {}

  return ret;
}

uint8_t uartRead(uint8_t channel)
{
  uint8_t ret = 0;



  ret = XUartPs_ReadReg(UartPs.Config.BaseAddress, XUARTPS_FIFO_OFFSET);

  return ret;
}

int32_t uartPrintf(uint8_t channel, const char *fmt, ...)
{
  int32_t ret = 0;
  va_list arg;
  va_start (arg, fmt);
  int32_t len;
  static char print_buffer[255];


  if (uartIsEnable(channel) == false ) return 0;

  len = vsnprintf(print_buffer, 255, fmt, arg);
  va_end (arg);

  ret = uartWrite(channel, (uint8_t *)print_buffer, len);

  return ret;
}

int32_t uartPrint(uint8_t channel, uint8_t *p_str)
{
  int32_t index = 0;

  if (uartIsEnable(channel) == false ) return 0;

  while(1)
  {
    uartPutch(channel, p_str[index]);

    if (p_str[index] == 0)
    {
      break;
    }

    index++;

    if (index > 255)
    {
      break;
    }
  }


  return index;
}

