/*
 *  ap.c
 *
 *  Created on: 2016. 7. 13.
 *      Author: Baram
 */

#include "ap.h"









void apInit(void)
{
}

void apMain(void)
{
  uint32_t i;
  uint32_t pre_time[2];


  uartOpen(_DEF_UART1, 115200);

  while(1)
  {
    pre_time[0] = micros();
    pre_time[1] = millis();
    //delay(1000);
    //xil_printf("test %d, %d ms, %d us\n", i++, millis()-pre_time[1], micros()-pre_time[0]);
    //xil_printf("rx : %X\n", uartAvailable(_DEF_UART1));

    if (uartAvailable(_DEF_UART1))
    {
      uartPrintf(_DEF_UART1, "rx : %X\n", uartRead(_DEF_UART1));
    }

  }
}

