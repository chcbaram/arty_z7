/*
 * main.c
 *
 *  Created on: 2017. 3. 19.
 *      Author: baram
 */
#include "main.h"



void mainInit(void);



void led_isr(void *arg)
{
  ledToggle(0);
}


int main(void)
{
  mainInit();


  cmdifLoop();
  apMain();

  return 0;
}

void mainInit(void)
{
  swtimer_handle_t led_timer_h;


  bspInit();
  hwInit();
  apInit();

  led_timer_h = swtimerGetHandle();
  swtimerSet(led_timer_h, 100, LOOP_TIME, led_isr, NULL);
  swtimerStart(led_timer_h);

  cmdifBegin(_DEF_UART1, 115200);

}
